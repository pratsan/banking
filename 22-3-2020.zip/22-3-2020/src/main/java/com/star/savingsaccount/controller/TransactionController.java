
package com.star.savingsaccount.controller;

import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.star.savingsaccount.dto.FundTransferDto;
import com.star.savingsaccount.dto.HistoryReqDto;
import com.star.savingsaccount.dto.HistoryRespDto;
import com.star.savingsaccount.dto.ResponseDto;
import com.star.savingsaccount.entity.TransactionHistory;
import com.star.savingsaccount.exception.InvalidStatusDateException;
import com.star.savingsaccount.exception.NotInaRangeException;
import com.star.savingsaccount.exception.RecordNotFoundException;
import com.star.savingsaccount.exception.TransactionException;
import com.star.savingsaccount.service.FundtransferService;
import com.star.savingsaccount.service.TransactionHistoryService;

@RestController
public class TransactionController {

	@Autowired
	TransactionHistoryService transactionHistoryService;

	@Autowired
	private FundtransferService fundtransferService;

	/**
	 * This method is used give the summary of transaction
	 * @author Nagajyoti
	 * @since 2020-03-17
	 * @param userId -Here we use userId as a reference to the particular user
	 * HistoryResponseDto- is a response dto contains the summary of  transaction
	 * @return ResponseEntity Object along with status code and message
	 */

	@PostMapping("users/{userId}/transactions/history")
	public ResponseEntity<HistoryRespDto> transactionHistory(@PathVariable(name = "userId") long userId,
			@RequestBody HistoryReqDto historyReqDto) throws TransactionException ,InvalidStatusDateException,RecordNotFoundException {
		HistoryRespDto responseDto = transactionHistoryService.transactionHistory(userId, historyReqDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

	/**
	 * This method is used for transaction
	 * @author Prateek
	 * @since 2020-03-17
	 * @param fundTransferDto -contains the accountNumber , userId , amount as request params for transaction
	 * ResponseDto- gives success or failure message
	 * @return ResponseEntity Object along with status code and message
	 */
	@PostMapping("transactions/transaction")
	public ResponseEntity<ResponseDto> fundTransfer(@RequestBody FundTransferDto fundTransferDto)
			throws TransactionException,RecordNotFoundException,NotInaRangeException  {
		TransactionHistory transactionHistory = new TransactionHistory();
		transactionHistory.setTransactionDate(new Date());
		BeanUtils.copyProperties(fundTransferDto, transactionHistory);
		ResponseDto responseDto = fundtransferService.fundTransfer(transactionHistory);
		return new ResponseEntity<>(responseDto,HttpStatus.OK);
	}
	
	

}
