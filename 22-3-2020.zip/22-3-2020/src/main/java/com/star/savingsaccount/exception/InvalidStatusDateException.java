/**
 * 
 */
package com.star.savingsaccount.exception;

/**
 * @author User1
 *
 */
public class InvalidStatusDateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4475586267204218967L;

	public InvalidStatusDateException(String message) {
		super(message);
	}
	
	
	

}
