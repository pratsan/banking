/**
 * 
 */
package com.star.savingsaccount.dto;

/**
 * @author User1
 *
 */
public class HistoryReqDto {
	
	private String fromDate;
	private String todate;
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getTodate() {
		return todate;
	}
	public void setTodate(String todate) {
		this.todate = todate;
	}
	
	

}
